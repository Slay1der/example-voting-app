# Evidence log

Terminal output captured while building Capstone 1. Screenshots are in [`screenshots/`](screenshots/).

## Environment rebuilt from code (27 Oct 2026, after a full `terraform destroy`)

```
aws_eks_cluster.main: Creation complete after 9m20s [id=capstone-eks]
aws_eks_node_group.main: Creation complete after 1m20s [id=capstone-eks:capstone-nodes]

Apply complete! Resources: 8 added, 0 changed, 0 destroyed.

Outputs:

cluster_name = "capstone-eks"
kubeconfig_command = "aws eks update-kubeconfig --region us-west-2 --name capstone-eks"
```

## Nodes ready

```
$ kubectl get nodes
NAME                                         STATUS   ROLES    AGE     VERSION
ip-172-31-24-2.us-west-2.compute.internal    Ready    <none>   2m37s   v1.37.1-eks-39aca56
ip-172-31-59-20.us-west-2.compute.internal   Ready    <none>   2m36s   v1.37.1-eks-39aca56
```

## Helm install

```
$ helm install voting ./helm/voting-app --set image.tag=$(git rev-parse HEAD)
NAME: voting
NAMESPACE: default
STATUS: deployed
REVISION: 1
DESCRIPTION: Install complete
```

## App running on EKS

```
$ kubectl get pods
NAME                      READY   STATUS    RESTARTS   AGE
db-cdc95cd47-s8s5p        1/1     Running   0          71s
redis-56df5d468c-hz928    1/1     Running   0          71s
result-7f884d6b4d-qvms9   1/1     Running   0          71s
vote-7b4df478bb-qwfxt     1/1     Running   0          71s
worker-6f648fb96f-rd6mm   1/1     Running   0          71s
```

## Free-tier node failure (root cause found in the Auto Scaling Group log)

```
$ aws autoscaling describe-scaling-activities --region us-west-2 --max-items 5
"status": "Failed",
"why": "Could not launch On-Demand Instances. InvalidParameterCombination - The specified instance type is not eligible for Free Tier. ..."
```

Fixed by switching the node group from `t3.medium` to `m7i-flex.large`.

## Screenshots

| File | Shows |
|---|---|
| `01-compose-all-services-up.png` | All five services running locally with Docker Compose |
| `02-debug-iptables-legacy-forward-drop.png` | Root cause of "Waiting for db": legacy FORWARD policy DROP, only `docker0` allowed |
| `03-debug-fixed-worker-connected-to-db.png` | After the fix: port 5432 open, worker connected to db and redis |
| `04-vote-image-runs-as-appuser.png` | Hardened vote image runs as non-root `appuser` |
| `05-worker-image-runs-as-appuser.png` | Hardened worker image runs as non-root `appuser` |
| `06-ci-trivy-action-version-not-found.png` | First pipeline failure: Trivy action tag did not exist |
| `07-ci-vote-passes-result-worker-blocked.png` | Trivy blocks result and worker (end-of-life base images) |
| `08-trivy-critical-system-drawing-common.png` | CRITICAL CVE-2021-24112 in a transitive NuGet dependency |
| `09-trivy-debian-11-end-of-life.png` | .NET 7 runtime image on unsupported Debian 11 |
| `10-upgraded-pinned-dotnet8-node22.png` | Upgraded and digest-pinned .NET 8 and Node 22 base images |
| `11-worker-on-dotnet8-connected.png` | Worker on .NET 8 still connects to Redis |
| `12-ci-unknown-blob-on-push.png` | Registry `unknown blob` error, fixed by pushing with Buildx |
